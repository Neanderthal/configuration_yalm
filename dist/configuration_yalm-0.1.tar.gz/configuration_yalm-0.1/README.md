This is the packed configuration and model transfomerss files for HuYalm model from BlackSamorez/HuYaLM-100B-fp16
